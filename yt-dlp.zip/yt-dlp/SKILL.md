---
name: yt-dlp
description: Use quando o Juta quer baixar coisas do YouTube ou de outro site de vídeo — vídeo, áudio, legenda/transcrição salva em texto (.txt), título/metadata, playlist. Triggers válidos: invocação explícita `/yt-dlp`; ou linguagem natural tipo "baixa esse vídeo", "pega a transcrição/legenda desse vídeo", "salva o áudio", "extrai o texto desse vídeo". Também é o fallback quando o NotebookLM falha ao processar fonte do YouTube (a skill notebooklm referencia esta).
---

# yt-dlp

## Invocação nesta máquina

Sem `yt-dlp.exe` no PATH e sem deno — usar **módulo Python + runtime node** (Node v24 instalado). O `--remote-components ejs:github` baixa o solver de JS challenge do YouTube (sem ele, formatos somem e aparece warning "n challenge solving failed"):

```powershell
$env:PYTHONIOENCODING='utf-8'; py -m yt_dlp --js-runtimes node --remote-components ejs:github <args>
```

Todos os exemplos abaixo assumem esse prefixo (abreviado como `ytdlp`).

## Receitas (todas verificadas nesta máquina)

### Transcrição em texto — .txt com o título do vídeo no nome

Duas etapas: baixar legenda .vtt nomeada pelo título, converter pra texto limpo (sem timestamps, sem duplicatas do ASR):

```powershell
# vídeo em português; se for em inglês usar --sub-langs "en,en-orig"
ytdlp --skip-download --write-subs --write-auto-subs --sub-langs "pt,pt-orig" --sub-format vtt --sleep-subtitles 2 -o "%(title)s.%(ext)s" <URL>
Get-ChildItem *.vtt        # nome real sai sanitizado (`?`→`？`, `|`→`｜`) — pegar o caminho daqui
py C:\Users\Juta\.claude\skills\yt-dlp\vtt2txt.py "<caminho-do-vtt>"
```

- `--write-subs` pega legenda manual; `--write-auto-subs` a automática (`pt-orig`/`en-orig` = trilha ASR original). Vem o que existir; se vierem as duas, **converter a manual (sem `-orig`)** — a ASR é mais suja.
- **Pedir só as línguas prováveis do vídeo, exatas, nunca wildcard** — `pt.*` puxa dezenas de traduções automáticas, e cada request de legenda conta pro rate limit do YouTube (HTTP 429). O `--sleep-subtitles 2` espaça os requests.
- **No primeiro 429 o yt-dlp ABORTA as línguas restantes** (exit 1, mesmo com arquivos já gravados). Conferir `Get-ChildItem *.vtt` antes de retentar — e retentar só com a língua que faltou, ou esperar uns minutos.
- O vtt2txt.py imprime o caminho do .txt gerado. Conversão não precisa de ffmpeg.

### Título / metadata (sem baixar nada)

```powershell
ytdlp --print "%(title)s" --skip-download <URL>
ytdlp -J <URL>                # JSON completo (duration, uploader, chapters...)
ytdlp --list-subs <URL>       # quais legendas existem
```

### Áudio

```powershell
ytdlp -f "ba[ext=m4a]/b" -o "%(title)s.%(ext)s" <URL>
```

### Vídeo

```powershell
ytdlp -f "b[ext=mp4]/b" -o "%(title)s.%(ext)s" <URL>
```

`b...` = formato progressivo (vídeo+áudio num arquivo só, tipicamente ≤720p). Não usar o default `bv*+ba` — exige merge com ffmpeg.

### Playlist

```powershell
ytdlp -o "%(playlist_index)02d - %(title)s.%(ext)s" <URL-da-playlist>
# só alguns itens: --playlist-items 1-5
```

## Limites desta máquina (ffmpeg NÃO instalado)

Falham e não há contorno sem instalar: `-x --audio-format mp3`, merge `bv*+ba` (1080p+), `--convert-subs`, `--download-sections`, `--embed-*`. Se o Juta precisar disso: `winget install ffmpeg` e reabrir o shell.

## Erros comuns

| Sintoma | Causa → Fix |
|---|---|
| `yt-dlp não é reconhecido` | exe fora do PATH → sempre `py -m yt_dlp` |
| HTTP 429 baixando legendas | rate limit do YouTube (acontece até com línguas exatas, e aborta as línguas restantes) → conferir o que já baixou, retentar só o que falta com `--sleep-subtitles 2`, ou esperar uns minutos |
| "n challenge solving failed" / formato faltando | faltou `--js-runtimes node --remote-components ejs:github` |
| `UnicodeEncodeError` / `�` no output | faltou `$env:PYTHONIOENCODING='utf-8'` |
| `？ ｜` no nome do arquivo | sanitização Windows normal; `--restrict-filenames` se precisar ASCII puro |
| Exit code ≠ 0 mas arquivos baixados | falha parcial (ex: 1 idioma de legenda deu 429) — conferir `Get-ChildItem` antes de retentar |

## Manutenção

YouTube quebra extractors velhos — se aparecer erro de extração novo: `py -m pip install -U yt-dlp`. Flags raros: `py -m yt_dlp --help`.
